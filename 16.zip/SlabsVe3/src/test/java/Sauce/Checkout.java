package Sauce;

 	import org.openqa.selenium.*;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.Assert;
	import org.testng.annotations.*;

	public class Checkout {

	    WebDriver driver;

	    @BeforeMethod
	    public void setUp() {
 	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.saucedemo.com/v1/");
	        
	        // Login
	        driver.findElement(By.id("user-name")).sendKeys("standard_user");
	        driver.findElement(By.id("password")).sendKeys("secret_sauce");
	        driver.findElement(By.id("login-button")).click();
	    }

	    @Test
	    public void testSuccessfulCheckout() throws InterruptedException {
 	        driver.findElement(By.className("btn_inventory")).click();

 	        driver.findElement(By.className("shopping_cart_link")).click();

 	        driver.findElement(By.className("checkout_button")).click();

 	        driver.findElement(By.id("first-name")).sendKeys("John");
	    	try {
	            Thread.sleep(2000);   
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        driver.findElement(By.id("last-name")).sendKeys("Doe");
	    	try {
	            Thread.sleep(2000);  
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        driver.findElement(By.id("postal-code")).sendKeys("12345");

	        // Continue to next step
	        driver.findElement(By.className("cart_button")).click();

	        // Finish purchase
	        driver.findElement(By.className("cart_button")).click();  
	    	try {
	            Thread.sleep(2000);  
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

 	        WebElement confirmationHeader = driver.findElement(By.className("complete-header"));
	        Assert.assertEquals(confirmationHeader.getText(), "THANK YOU FOR YOUR ORDER",
	                "Order confirmation message not displayed correctly");    	try {
	                    Thread.sleep(2000);  
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            	try {
	                    Thread.sleep(2000);  
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }

	        
	        
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }
	}
	
	
	

