package Sauce;

		import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.chrome.ChromeDriver;
		import org.testng.Assert;
		import org.testng.annotations.*;

		public class Automation {

		    WebDriver driver;

		    @BeforeMethod
		    public void setUp() {
		  
		        driver = new ChromeDriver();
		        driver.get("https://www.saucedemo.com/v1/");
		    }

		    @DataProvider(name = "credentials")
		    public Object[][] credentialData() {
		        return new Object[][] {
		            {"standard_user", "secret_sauce"},
		            {"problem_user", "secret_sauce"},
		            {"performance_glitch_user", "secret_sauce"}
		        };
		    }

		    @Test(dataProvider = "credentials")
		    public void testLoginAndHomepageLoad(String username, String password) {
		        
		        WebElement usernameField = driver.findElement(By.id("user-name"));
		        WebElement passwordField = driver.findElement(By.id("password"));
		        WebElement loginButton = driver.findElement(By.id("login-button"));

		        usernameField.sendKeys(username);
		        passwordField.sendKeys(password);
		        loginButton.click();

		        
		        WebElement header = driver.findElement(By.className("product_label"));
		        String headerText = header.getText();
		        Assert.assertEquals(headerText, "Products", "Homepage did not load correctly");
		    }

		    @AfterMethod
		    public void tearDown() {
		        if (driver != null) {
		            driver.quit();
		        }
		    }
		

	}


