package Sauce;
 import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;

import java.util.ArrayList;
import java.util.List;

public class ProductFilterTest{

   WebDriver driver;

    @BeforeMethod
    public void setUp() {
         driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com/v1/");
        
        // Login
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
    }

    @Test
    public void testProductFilterLowToHigh() {
    	
     	
         Select sortDropdown = new Select(driver.findElement(By.className("product_sort_container")));
        sortDropdown.selectByValue("lohi");   
    	try {
            Thread.sleep(2000);  
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


          

         List<WebElement> productNames = driver.findElements(By.className("inventory_item_name"));
        System.out.println("Products sorted by Price (Low to High):");
        for (WebElement name : productNames) {
            System.out.println(name.getText());
        }
    }

    @AfterMethod
    public void tearDown() {
    	try {
            Thread.sleep(1000);  
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.quit();
    }
}