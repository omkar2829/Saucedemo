package Sauce;

 	import org.openqa.selenium.*;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.Select;
	import org.testng.Assert;
	import org.testng.annotations.*;

	import java.util.List;

	public class CartOperationsTest {

	    WebDriver driver;

	    @BeforeMethod
	    public void setUp() {
 	        driver = new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.saucedemo.com/v1/");
	        
	        // Login
	        driver.findElement(By.id("user-name")).sendKeys("standard_user");
	        driver.findElement(By.id("password")).sendKeys("secret_sauce");
	        driver.findElement(By.id("login-button")).click();
	    }

	    @Test
	    public void testAddProductToCart() throws InterruptedException {
 	        Select sortDropdown = new Select(driver.findElement(By.className("product_sort_container")));
	        sortDropdown.selectByValue("lohi");
	        Thread.sleep(1000);  

 	        List<WebElement> productNames = driver.findElements(By.className("inventory_item_name"));
	        List<WebElement> addButtons = driver.findElements(By.className("btn_inventory"));

	        String selectedProduct = productNames.get(0).getText();
	        addButtons.get(0).click();  

 	        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
	        Assert.assertEquals(cartBadge.getText(), "1", "Cart badge should show 1 item");

 	        driver.findElement(By.className("shopping_cart_link")).click();
	        Thread.sleep(1000);  

 	        WebElement cartItemName = driver.findElement(By.className("inventory_item_name"));
	        Assert.assertEquals(cartItemName.getText(), selectedProduct, "Product in cart does not match selected item");
	    }

	    @AfterMethod
	    public void tearDown() {
	        driver.quit();
	    }
	}

